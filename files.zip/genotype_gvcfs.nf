process GENOTYPE_GVCFS {
    tag "${chrom}"
    label 'process_medium'

    conda 'bioconda::gatk4=4.4.0.0'
    container 'broadinstitute/gatk:4.4.0.0'

    input:
    tuple val(chrom), path(genomicsdb)

    output:
    tuple val(chrom), path("${chrom}.genotyped.vcf.gz"), path("${chrom}.genotyped.vcf.gz.tbi"), emit: genotyped_vcf

    script:
    """
    gatk GenotypeGVCFs \\
        --reference ${params.reference} \\
        --variant gendb://${genomicsdb} \\
        --output ${chrom}.genotyped.vcf.gz \\
        --intervals ${chrom} \\
        --tmp-dir . \\
        --java-options "-Xmx${task.memory.toGiga()}g"
    """
}
