process HAPLOTYPE_CALLER {
    tag "${sample_id}:${chrom}"
    label 'process_medium'

    conda 'bioconda::gatk4=4.4.0.0'
    container 'broadinstitute/gatk:4.4.0.0'

    input:
    tuple val(sample_id), path(bam), path(bai), val(chrom)

    output:
    tuple val(chrom), val(sample_id), path("${sample_id}.${chrom}.g.vcf.gz"), path("${sample_id}.${chrom}.g.vcf.gz.tbi"), emit: gvcf

    script:
    """
    gatk HaplotypeCaller \\
        --input ${bam} \\
        --output ${sample_id}.${chrom}.g.vcf.gz \\
        --reference ${params.reference} \\
        --intervals ${chrom} \\
        --emit-ref-confidence GVCF \\
        --tmp-dir . \\
        --java-options "-Xmx${task.memory.toGiga()}g"
    """
}
