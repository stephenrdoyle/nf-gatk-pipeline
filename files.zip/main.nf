#!/usr/bin/env nextflow
nextflow.enable.dsl=2

/*
 * GATK variant calling pipeline
 * Input: samplesheet CSV with columns: sample_id, bam
 * Steps: index (if needed) → validate → HaplotypeCaller (per sample × chromosome) → GenomicsDBImport → GenotypeGVCFs → GatherVcfs
 */

include { SAMTOOLS_INDEX     } from './modules/samtools_index'
include { VALIDATE_BAM       } from './modules/validate_bam'
include { HAPLOTYPE_CALLER   } from './modules/haplotype_caller'
include { GENOMICS_DB_IMPORT } from './modules/genomics_db_import'
include { GENOTYPE_GVCFS     } from './modules/genotype_gvcfs'
include { GATHER_VCFS        } from './modules/gather_vcfs'

workflow {

    // ── inputs ────────────────────────────────────────────────────────────────

    // Samplesheet: sample_id,bam  (no bai column)
    ch_samples = Channel
        .fromPath(params.samplesheet)
        .splitCsv(header: true)
        .map { row ->
            def bam = file(row.bam)
            def bai = file("${row.bam}.bai")
            tuple(row.sample_id, bam, bai.exists() ? bai : null)
        }

    // Split into samples that already have an index and those that need one
    ch_has_index    = ch_samples.filter { id, bam, bai -> bai != null }
    ch_needs_index  = ch_samples
        .filter  { id, bam, bai -> bai == null }
        .map     { id, bam, bai -> tuple(id, bam) }

    ch_newly_indexed = SAMTOOLS_INDEX(ch_needs_index)
    // emits: [sample_id, bam, bai]

    // Reunite both streams
    ch_all_samples = ch_has_index.mix(ch_newly_indexed)

    // Chromosome / interval list (e.g. ['chr1','chr2',...,'chrX'])
    ch_chroms = Channel.from(params.chromosomes)

    // ── step 1 + 2: validate BAMs (per sample) ───────────────────────────────

    ch_validated = VALIDATE_BAM(ch_all_samples)

    // ── step 3: scatter HaplotypeCaller over sample × chromosome ─────────────
    //
    //   .combine() produces: [sample_id, bam, bai, chrom]
    //   One task per (sample, chrom) pair — fully parallel.

    ch_hc_input = ch_validated.combine(ch_chroms)

    ch_gvcfs = HAPLOTYPE_CALLER(ch_hc_input)
    // emits: [chrom, sample_id, gvcf, tbi]

    // ── step 4a: gather all samples per chromosome, then GenomicsDBImport ────
    //
    //   groupTuple(by: 0) waits until every sample has emitted a gVCF for
    //   a given chromosome before releasing that batch downstream.

    ch_db_input = ch_gvcfs
        .groupTuple(by: 0)
        // now: [chrom, [sample_ids], [gvcfs], [tbis]]

    ch_dbs = GENOMICS_DB_IMPORT(ch_db_input)
    // emits: [chrom, genomicsdb_path]

    // ── step 4b: joint genotyping per chromosome ──────────────────────────────

    ch_genotyped = GENOTYPE_GVCFS(ch_dbs)
    // emits: [chrom, vcf, tbi]

    // ── step 4c: gather per-chromosome VCFs into single cohort VCF ───────────
    //
    //   .collect() waits for all chromosomes before running GatherVcfs once.

    ch_vcfs_to_gather = ch_genotyped
        .map { chrom, vcf, tbi -> tuple(vcf, tbi) }
        .collect()

    GATHER_VCFS(ch_vcfs_to_gather)
    // emits: cohort.vcf.gz + .tbi
}
