#!/usr/bin/env bash
# run_pipeline.sh — submit the GATK variant calling pipeline to LSF
#
# Usage:
#   bsub < run_pipeline.sh
#   or directly: bash run_pipeline.sh
#
# Edit the CONFIG section below before submitting.

# ── LSF directives ────────────────────────────────────────────────────────────
#BSUB -J gatk_pipeline
#BSUB -q normal
#BSUB -n 1
#BSUB -M 4096
#BSUB -R "rusage[mem=4096]"
#BSUB -W 72:00
#BSUB -o logs/pipeline_%J.out
#BSUB -e logs/pipeline_%J.err

set -euo pipefail

# ── CONFIG — edit these before running ────────────────────────────────────────

SAMPLESHEET="samplesheet.csv"
REFERENCE="/path/to/hg38.fa"
OUTDIR="results"
LSF_QUEUE="normal"
LSF_PROJECT=""                  # leave empty if not using a project code

# ── environment ───────────────────────────────────────────────────────────────

mkdir -p logs

module load nextflow    # or: export PATH=/path/to/nextflow:$PATH

# ── run ───────────────────────────────────────────────────────────────────────

NF_OPTS=(
    --samplesheet  "${SAMPLESHEET}"
    --reference    "${REFERENCE}"
    --outdir       "${OUTDIR}"
    --lsf_queue    "${LSF_QUEUE}"
)

# Append project flag only if set
[[ -n "${LSF_PROJECT}" ]] && NF_OPTS+=(--lsf_project "${LSF_PROJECT}")

nextflow run main.nf \
    "${NF_OPTS[@]}"  \
    -profile lsf     \
    -resume          \
    -with-report  "${OUTDIR}/reports/nextflow_report.html" \
    -with-timeline "${OUTDIR}/reports/nextflow_timeline.html" \
    -with-dag      "${OUTDIR}/reports/pipeline_dag.html"
