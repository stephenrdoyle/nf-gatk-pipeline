process GENOMICS_DB_IMPORT {
    tag "${chrom}"
    label 'process_medium'

    conda 'bioconda::gatk4=4.4.0.0'
    container 'broadinstitute/gatk:4.4.0.0'

    input:
    tuple val(chrom), val(sample_ids), path(gvcfs), path(tbis)

    output:
    tuple val(chrom), path("genomicsdb_${chrom}"), emit: genomicsdb

    script:
    // Build -V sample1.g.vcf.gz -V sample2.g.vcf.gz ... argument string
    def vcf_inputs = gvcfs.collect { "-V ${it}" }.join(' \\\n        ')
    """
    gatk GenomicsDBImport \\
        ${vcf_inputs} \\
        --genomicsdb-workspace-path genomicsdb_${chrom} \\
        --intervals ${chrom} \\
        --tmp-dir . \\
        --java-options "-Xmx${task.memory.toGiga()}g"
    """
}
