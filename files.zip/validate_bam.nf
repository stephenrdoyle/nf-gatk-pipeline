process VALIDATE_BAM {
    tag "${sample_id}"
    label 'process_low'

    conda 'bioconda::gatk4=4.4.0.0'
    container 'broadinstitute/gatk:4.4.0.0'

    input:
    tuple val(sample_id), path(bam), path(bai)   // bai guaranteed present by this point

    output:
    tuple val(sample_id), path(bam), path(bai), emit: validated_bam

    script:
    """
    gatk ValidateSamFile \\
        --INPUT ${bam} \\
        --MODE SUMMARY \\
        --IGNORE_WARNINGS true

    # If read groups are missing, add them
    if ! samtools view -H ${bam} | grep -q '^@RG'; then
        gatk AddOrReplaceReadGroups \\
            --INPUT ${bam} \\
            --OUTPUT ${sample_id}.rg.bam \\
            --RGLB lib1 \\
            --RGPL ILLUMINA \\
            --RGPU unit1 \\
            --RGSM ${sample_id}
        samtools index ${sample_id}.rg.bam
    fi
    """
}
