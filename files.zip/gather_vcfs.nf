process GATHER_VCFS {
    tag "cohort"
    label 'process_low'
    publishDir params.outdir, mode: 'copy'

    conda 'bioconda::gatk4=4.4.0.0'
    container 'broadinstitute/gatk:4.4.0.0'

    input:
    // collected list of [vcf, tbi] pairs from all chromosomes
    path(vcfs_and_tbis)

    output:
    tuple path("cohort.vcf.gz"), path("cohort.vcf.gz.tbi"), emit: cohort_vcf

    script:
    // Pull out only the .vcf.gz files (not the .tbi) and sort by chromosome
    // GatherVcfs requires inputs to be in chromosomal order
    def vcf_list = vcfs_and_tbis
        .findAll { it.name.endsWith('.vcf.gz') }
        .sort()
        .collect { "-I ${it}" }
        .join(' \\\n        ')
    """
    gatk GatherVcfs \\
        ${vcf_list} \\
        --OUTPUT cohort.vcf.gz

    gatk IndexFeatureFile --input cohort.vcf.gz
    """
}
